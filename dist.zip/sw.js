/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-39884a30'], (function (workbox) { 'use strict';

  self.addEventListener('message', event => {
    if (event.data && event.data.type === 'SKIP_WAITING') {
      self.skipWaiting();
    }
  });

  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "css/AIPolice-DzCTTxWp.css",
    "revision": "f98dd887323a38d63d59b2b3e3e9549c"
  }, {
    "url": "css/chat-review-file-C2GEbNwc.css",
    "revision": "41af56562730659768c3c938cca2b0d7"
  }, {
    "url": "css/chatUrls-C3mLQoKp.css",
    "revision": "28823c55e7880da78739d106db987e0f"
  }, {
    "url": "css/Detail-CARwCCyR.css",
    "revision": "324dc42806b85cec98fcb6a5b8bc3846"
  }, {
    "url": "css/el-card-BRs6t4Sx.css",
    "revision": "e98ab9eeab53d0ce744d772b04b1c1b5"
  }, {
    "url": "css/el-empty-BSOUNWN9.css",
    "revision": "07b49a431c9a17e67307e0f1ddf85391"
  }, {
    "url": "css/financial-analysis-assistant-DVMjJcH_.css",
    "revision": "759065a52c7f6b99edd8e880ed4c4417"
  }, {
    "url": "css/index-B4K0oZMm.css",
    "revision": "8c4bdd8b4371d1ad9d75c90d2c5621ab"
  }, {
    "url": "css/Index-C5mzOtCB.css",
    "revision": "abc8d5d4ca6678d2a18ea31e8c33231f"
  }, {
    "url": "css/KnowledgeBase-kDp0Evoh.css",
    "revision": "566c3823428b55acca6496616acc1120"
  }, {
    "url": "css/KnowledgeGraph-DJuk0H9x.css",
    "revision": "d2c9c3544c8255ddb89760d16ebe2214"
  }, {
    "url": "css/social-activity-assistant-BzBT78nZ.css",
    "revision": "2c1b4f1afb52262fc3f2c9bcc7905773"
  }, {
    "url": "index.html",
    "revision": "da455d79e76d93420ac658208a904ab9"
  }, {
    "url": "index.js",
    "revision": "134aaa96ec42f7942326d2c7b405fd3d"
  }, {
    "url": "js/AIPolice-CvWnpt-z.js",
    "revision": "2259b40f9b6f31cfc77b07dd0d54119a"
  }, {
    "url": "js/CaseReview-BGxnoMNZ.js",
    "revision": "6b04f3a281e53189832571f9a2d68824"
  }, {
    "url": "js/chat-review-Clm6AeXg.js",
    "revision": "41ae0d6501a35c22e1a5c8dabfc0492e"
  }, {
    "url": "js/chat-review-file-NDOd_RjN.js",
    "revision": "d8af2f93915bfbc608085f6612e3d5fe"
  }, {
    "url": "js/chatUrls-vw8x1ECn.js",
    "revision": "299ef8148689a07d5fce257b4a6b90e7"
  }, {
    "url": "js/Detail-ym5HyrHz.js",
    "revision": "16ec062cd459798a9f3556fecfddfb50"
  }, {
    "url": "js/elementplus-CGeHhV9O.js",
    "revision": "2672ff1c67812b6c292f9793e0984f4c"
  }, {
    "url": "js/financial-analysis-assistant-UgHrP1n1.js",
    "revision": "12ec0950d1ea7bd9b1ec00dcbe956948"
  }, {
    "url": "js/FinancialAnalysis-BN3eJ7OK.js",
    "revision": "2ddd20c730e6b9ae1c5ddb60310f62f5"
  }, {
    "url": "js/index-B9IMxrmZ.js",
    "revision": "3a832ec006fb6a9be0bcf2015f18f8eb"
  }, {
    "url": "js/Index-Bdg32YAx.js",
    "revision": "7bc95656ca3d7957517874b64be9fa66"
  }, {
    "url": "js/KnowledgeBase-XSqyWoK1.js",
    "revision": "4b6fbacc86018076d47b1a97b3b7760e"
  }, {
    "url": "js/KnowledgeGraph-DsGo83od.js",
    "revision": "28de747afc20e3beb64b7133653490ce"
  }, {
    "url": "js/LegalConsultant-DEFsnOSA.js",
    "revision": "34a5c428ef00a2b1c42323e34ea73015"
  }, {
    "url": "js/social-activity-assistant-DRNxe7RG.js",
    "revision": "4b74b53c21c66353b741c0557eea738d"
  }, {
    "url": "js/SocialActivity-CAffpjCm.js",
    "revision": "c04eb2291b664dd7c216d1218e831d1e"
  }, {
    "url": "js/TextReview-GAYdPOPv.js",
    "revision": "6082f77777cf881d275947d97967cefc"
  }, {
    "url": "js/vue-DKseC1u-.js",
    "revision": "8150d7c7a16049048b74490d1441bf77"
  }, {
    "url": "js/workbox-window.prod.es5-CC4K6GI8.js",
    "revision": "5ef383bf46a4ca2b801773c11024cde2"
  }, {
    "url": "mockServiceWorker.js",
    "revision": "b09d0cac79f16421cb81db1a6c773d5c"
  }, {
    "url": "pwa-192x192.png",
    "revision": "f24c9384006bbc8de95ed69990459dca"
  }, {
    "url": "pwa-512x512.png",
    "revision": "4db5b8fe442a8f8fdc6e35cd40138057"
  }, {
    "url": "manifest.webmanifest",
    "revision": "7e32a248dc4e60b1f0d8291552d50843"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
